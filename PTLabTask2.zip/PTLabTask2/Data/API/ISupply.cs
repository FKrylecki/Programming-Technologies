﻿namespace Data.API
{
    internal interface ISupply : IEvent
    {

    }
}
