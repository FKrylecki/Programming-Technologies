﻿namespace Data.API
{
    internal interface IReturn : IEvent
    {
    }
}
