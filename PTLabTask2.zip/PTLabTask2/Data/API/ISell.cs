﻿namespace Data.API
{
    internal interface ISell : IEvent
    {
    }
}
