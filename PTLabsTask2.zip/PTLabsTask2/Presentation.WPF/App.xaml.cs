﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using Presentation.WPF.ViewModel;

namespace Presentation.WPF
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            //base.OnStartup(e);
            //MainWindow window = new MainWindow();
            //ViewModelMain vm = new ViewModelMain();
            //ViewModel VM = new ViewModel();
            //window.DataContext = vm;
            //window.Show();
        }
    }
}
